package sample;

/**
 Prog2 calls TuitionManager and runs the program.
 @author Rose Sirohi, Caitlyn Romano
 */
public class Proj3
{
    public static void main(String [] args)
    {
        new TuitionManager().readInput();
    }
}
